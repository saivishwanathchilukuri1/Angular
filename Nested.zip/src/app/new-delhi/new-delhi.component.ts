import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-delhi',
  templateUrl: './new-delhi.component.html',
  styleUrls: ['./new-delhi.component.css']
})
export class NewDelhiComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
