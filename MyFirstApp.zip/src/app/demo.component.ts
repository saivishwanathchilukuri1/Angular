import { Component } from "@angular/core";

@Component({
    selector:'demo',
    template: '<h1>Welcome</h1>'

})
export class DemoComponent{
    
}