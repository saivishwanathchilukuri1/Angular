import { Component } from '@angular/core';

@Component({
  selector: 'classdemo',
  templateUrl: './classdemo.component.html',
  styleUrls: ['./classdemo.component.css']
})
export class ClassdemoComponent  {
  public effects;
  public isBackEffectSelected;
  public isTextEffectSelected;
  public isBorderEffectSelected;

}
