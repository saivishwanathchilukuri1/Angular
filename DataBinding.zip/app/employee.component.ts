import {Component} from '@angular/core';

@Component({
    selector:'emp',
    templateUrl:'./employee.component.html'
})
export class EmployeeComponent
{
    empname:string="Srikanth";
    empid:number=101;
    empage:number=30;
    isActive:boolean=true;
    gender:string="Male";
    country:string="India";
    companyadd:string="http://www.nareshit.com";

    ChangeData()
    {
        this.empid=102;
        this.empname="Sai";
        this.empage=5;
        this.isActive=false;
        this.gender="Male";
        this.country="USA";
    }

}