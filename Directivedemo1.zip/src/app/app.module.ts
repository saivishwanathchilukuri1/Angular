import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProductComponent } from './product.component';
import { FormsModule } from '@angular/forms';
import { IfdemoComponent } from './ifdemo.component';

@NgModule({
  declarations: [
    AppComponent,
    ProductComponent,
    IfdemoComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [IfdemoComponent]
})
export class AppModule { }
