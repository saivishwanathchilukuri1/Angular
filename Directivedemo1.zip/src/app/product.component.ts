import {Component} from '@angular/core';

@Component({
    selector:'product',
    templateUrl:'./product.component.html'

})

export class ProductComponent
{
    productName :string="Sai";
    productPrice:number=101;
    address:string="Antigonish";    
    inStock:boolean=true;


}