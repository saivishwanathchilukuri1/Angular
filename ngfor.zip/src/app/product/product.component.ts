import { Component } from '@angular/core';

@Component({
  selector: 'product',
  templateUrl: './product.component.html',
  styles: [
  ]
})
export class ProductComponent  {
  public products=[
    {Name:'Iphone XS',Price:55000},
    {Name:'Oneplus',Price:25000},
    {Name:'Samsung',Price:15000}
    
  ];
    public name;
    public price;
    public newProduct={Name:'',Price:0};
    public AddProduct(){
      this.newProduct{
        Name:this.name,
        Price:this.price
    

    };
    this.products.push(this.newProduct);
    this.name="";
    this.price="";
public RemoveProduct(index)
{
  var choice=confirm('Are you sure you want to delete');
  if(choice==true){
    this.products.splice(index,1);

  }
 
}


}
