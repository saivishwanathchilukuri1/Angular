import { Component } from '@angular/core';

@Component({
  selector: 'app-trackby',
  templateUrl: './trackby.component.html',
  styles: [
  ]
})
export class TrackbyComponent  {
  public products=[
    {Id:1,Name:'Iphone X',Price:55000,Image:'assets/iPhone.jpg'}
    {Id:2,Name:'One plus',Price:25000,Image:'assets/oneplus.jpg'}
  ];
  public AddItem()
 {
   this.products=[
      {Id:1,Name:'Iphone X',Price:58000,Image:'assets/iPhone.jpg'}
      {Id:2,Name:'One plus',Price:25000,Image:'assets/oneplus.jpg'}
      {Id:3,Name:'Iphone X',Price:58000,Image:'assets/iPhone.jpg'}
   ];
 }
 public TrackById(index,product)
 {
   return product.Id;
 }
}




