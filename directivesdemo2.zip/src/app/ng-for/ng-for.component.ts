import { Component} from '@angular/core';

@Component({
  selector: 'ng-for',
  templateUrl: './ng-for.component.html',
  styles: [
  ]
})
export class NgForComponent {
//  public products:Array<any> =['Laptop,'Mobile','Desktop','Printer'];
public Items:Array<any>=
  {
    category:'Electronics',
    products:['Mobile','Smart TV ','Smart Watch']
  },
  {
    category:'Fashion',
    products:['Leecooper','UCB','American Eagle']
  
  },
  {
    category:'Electrical',
    products:['Washing Machine','Geyser',' AC']
  }
];
}




