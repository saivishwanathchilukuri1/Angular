import { Component} from '@angular/core';


@Component({
    selector: 'ngifelse',
    templateUrl: './ngifelse.component.html'
    
})
export class NgifelseComponent  {
    isVisible:boolean=true;
    empName:string='Sai';
    empSalary:number=120202;
    empStatus:boolean=true;
}
