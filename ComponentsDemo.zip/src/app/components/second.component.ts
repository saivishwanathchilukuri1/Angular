import {Component} from '@angular/core';

@Component({
    selector:'second',
    templateUrl:'./second.component.html'
})
export class SecondComponent{
    subject:string="Angular";
    fee:number=10000;
}