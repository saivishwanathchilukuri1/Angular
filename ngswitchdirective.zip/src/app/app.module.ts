import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProductComponent } from './product/product.component';
import { FormsModule } from '@angular/forms';
import { IfdemoComponent } from './ifdemo.component';
import { NgifelseComponent } from './ngifelse.component';
import { NgForComponent } from './ng-for/ng-for.component';
import { TrackbyComponent } from './trackby/trackby.component';
import { ContainerComponent } from './container/container.component';
import { SwitchdemoComponent } from './switchdemo/switchdemo.component';


@NgModule({
  declarations: [
    AppComponent,
    ProductComponent,
    IfdemoComponent,
    NgifelseComponent,
    NgForComponent,
    TrackbyComponent,
    ProductComponent,
    ContainerComponent,
    SwitchdemoComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [SwitchdemoComponent]
})
export class AppModule { }
