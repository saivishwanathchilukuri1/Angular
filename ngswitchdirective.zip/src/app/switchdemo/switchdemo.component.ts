import { Component} from '@angular/core';

@Component({
  selector: 'switchdemo',
  templateUrl: './switchdemo.component.html',
  styles: [
  ]
})
export class SwitchdemoComponent  {
  public product={
    Name:'Iphone XS',
    Price:50000,
    Description: 'Iphone XS Series with 32 MP camera...',
    DateOfPurchase: new Date(),
    Image:'assets/iphone.jpg'
  };
  public  selectedView='info';

  public ChooseView(obj)
  {
    this.selectedView =obj.target.value;
  }

}
