import { Component} from '@angular/core';

@Component({
  selector: 'container',
  templateUrl: './container.component.html',
  styles: [
  ]
})
export class ContainerComponent {
  public products= [
    {Name:'IPhone XS',Price:58000,Category:'Electronics'},
    {Name:'OnePlus',Price:34000,Category:'Electronics'},
    {Name:'Mac Air Book',Price:90000,Category:'Electronics'},
    {Name:'Nike Shoes',Price:2000,Category:'Shoes'},
    {Name:'Puma Shoes',Price:1500,Category:'Shoes'}, 
    {Name:'Smart TV',Price:25000,Category:'Electrical'}, 
    {Name:'Android TV',Price:18000,Category:'Electrical'}
  ];

  public filter= 'Electronics';



}
