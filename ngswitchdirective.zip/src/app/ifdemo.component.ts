import {Component } from '@angular/core';

@Component({
    selector:'ifDemo',
    templateUrl:'./ifdemo.component.html'
})

export class IfdemoComponent{
    public isVisible:boolean=false;
    public btnText:string="show";

    public workshop:any={
        name:'Unit Testing',
        fee:'Free Workshop',
        image:'assets/employeeimage.jpg'
    };
    Display()
    {
        this .isVisible=(this.isVisible == false)?true: false;
        this.btnText=(this.btnText== 'Show')?'Hide':'Show';
    }
}
