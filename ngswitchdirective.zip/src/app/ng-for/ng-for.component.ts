import { Component} from '@angular/core';

@Component({
  selector: 'ng-for',
  templateUrl: './ng-for.component.html',
  styles: [
  ]
})
export class NgForComponent {
//  public products:Array<any> =['Laptop,'Mobile','Desktop','Printer'];
// public Items:Array<any>=[
//   {
//     category:'Electronics',
//     products:['Mobile','Smart TV ','Smart Watch']
//   },
//   {
//     category:'Fashion',
//     products:['Leecooper','UCB','American Eagle']
  
//   },
//   {
//     category:'Electrical',
//     products:['Washing Machine','Geyser',' AC']
//   }
// ];
public products=[
  {Id:1,Name:'Iphone X',Price:55000,Image:'assets/iPhone.jpg'}
  {Id:2,Name:'One plus',Price:35000,Image:'assets/oneplus.jpg'}
];
}




