import { Component} from '@angular/core';


@Component({
    selector: 'ngifelse',
    templateUrl: './ngifelse.component.html'
    
})
export class NgifelseComponent  {
    isVisible:boolean=true;
    empname:string='Sai';
    empsalary:number=120202;
    empstatus:boolean=true;
}
